package sajat;

public enum tevkor {

	SWFEJLESZTES,OKTATAS,TANACSADAS
}
